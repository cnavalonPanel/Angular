export class LogService {
  mostrarEnConsola(mensaje: string) {
    console.log("Mensaje: " + mensaje);
  }
}
